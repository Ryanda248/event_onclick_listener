package com.example.ryda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText et_email, et_password;
    Button login;
    String email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((R.layout.activity_main));

        et_email = findViewById(R.id.etEmail);
        et_password = findViewById(R.id.etPassword);
        login = findViewById(R.id.btSignin);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validasi();


            }
        });
    }

    public void validasi() {
        email = et_email.getText().toString();
        password = et_password.getText().toString();

        if (email.equals("ryanda@gmail.com") && password.equals("1122")) {
            Toast.makeText(MainActivity.this, "Login Berhasil", Toast.LENGTH_SHORT).show();
        }
        else if(email != ("ryanda@gmail.com") && password.equals("1122"))
        {
            Toast.makeText(MainActivity.this, "Email Salah", Toast.LENGTH_SHORT).show();
        }
        else if(email.equals("ryanda@gmail.com") && password != ("1122"))
        {
            Toast.makeText(MainActivity.this, "Password Salah", Toast.LENGTH_SHORT).show();
        }
        else if(email != ("ryanda@gmail.com") && password != ("1122"))
        {
            Toast.makeText(MainActivity.this, "Email dan Password Salah", Toast.LENGTH_SHORT).show();
        }
    }
}